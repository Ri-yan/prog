import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavbarComponent } from './navbar/navbar.component';
import { TranslationPipe } from './translation.pipe';
import { HeroComponent } from './hero/hero.component';
import { ServicesProvidedComponent } from './hero/services-provided/services-provided.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    TranslationPipe,
    HeroComponent,
    ServicesProvidedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
