import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-services-provided',
  templateUrl: './services-provided.component.html',
  styleUrls: ['./services-provided.component.scss']
})
export class ServicesProvidedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
